const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const  { CleanWebpackPlugin }  = require("clean-webpack-plugin");
const webpack = require('webpack');
module.exports={
	mode: 'development'
	,entry:{
		app:'./src/index.js'
	}
	,devtool: 'inline-source-map'//快速查找错误
	,devServer:{//热加载  webpack-dev-server   packgae.json需要修改
		contentBase:'./webpackst',
		hot: true
	}
	,plugins: [
      new CleanWebpackPlugin()
      ,new HtmlWebpackPlugin({
        title: '开22222环境'
      })
      ,new webpack.NamedModulesPlugin()//熱加載
      ,new webpack.HotModuleReplacementPlugin()//熱加載
    ]
    ,output:{
		filename:'[name].bundle.js'
		,path:path.join(__dirname,'webpackst')
	}
};
